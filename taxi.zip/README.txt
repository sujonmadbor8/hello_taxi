# bootstrap_template

Hello Taxi - html css js jq


font --------
p --- open sans  700
Fira Sans Condensed --500

color ---------
yellow #ffc61a
black #1F1F1F;
white : #ffffff